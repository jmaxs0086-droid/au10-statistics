# 澳洲幸运10统计 iOS 本地版

此目录是与根目录 Netlify 网站隔离的 iOS 应用工程；不会覆盖或删除现有网站与云端数据。

## 当前实现
- 使用现有统计网页的独立副本，记录保存在 WKWebView 的本机 localStorage。
- 不访问 Netlify Functions 或 Netlify Blobs。
- 打开 App 时尝试获取 API68 最新开奖；Swift 原生 URLSession 桥接绕过 file:// 页面的浏览器 CORS 限制，只允许请求 `https://api.api68.com/`。
- App 关闭时不后台定时更新；只在启动时尝试更新或由用户点击按钮。
- 不执行自动投注。

## 构建
仓库包含 `project.yml` 和 GitHub Actions 工作流 `.github/workflows/build-ios-unsigned.yml`。在 GitHub Actions 手动运行 **Build iOS IPA (unsigned)**，成功后下载 artifact `AU10Local-unsigned-IPA`。

## 重要：签名限制
工作流产出的是**未签名 IPA**，不能直接在普通 iPhone 上安装。需要用合法的 Apple 开发签名重新签名（例如在自己的 Mac/Xcode 上使用个人 Apple ID，或通过你信任的侧载工具）。不要把 Apple ID 密码交给陌生网站。仅有 Windows 电脑不提供本地 Xcode 构建能力，但 GitHub Actions 的 macOS runner 可编译工程。

## 数据备份
首次使用前，建议从原网站导出 JSON 备份，再在本地版中导入。原网站与本地版的数据存储彼此独立，不会自动合并。确认本地记录、导出/导入和最新开奖更新均正常后，再把它作为日常版本。
