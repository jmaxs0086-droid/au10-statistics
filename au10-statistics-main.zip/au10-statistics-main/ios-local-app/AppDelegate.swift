import UIKit
import WebKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    private var webView: WKWebView?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        // Keep the display awake while this app is in the foreground.
        UIApplication.shared.isIdleTimerDisabled = true
        let window = UIWindow(frame: UIScreen.main.bounds)
        let controller = UIViewController()
        controller.view.backgroundColor = UIColor(red: 237.0/255.0, green: 28.0/255.0, blue: 36.0/255.0, alpha: 1)

        window.rootViewController = controller
        window.makeKeyAndVisible()
        self.window = window

        let content = WKUserContentController()
        content.add(self, name: "api68")
        content.add(self, name: "betProbe")
        let bridge = """
        (() => {
          const originalFetch = window.fetch.bind(window);
          window.fetch = function(input, init) {
            const url = typeof input === 'string' ? input : (input && input.url) || '';
            if (url.startsWith('https://api.api68.com/')) {
              return new Promise((resolve, reject) => {
                const id = 'api68-' + Date.now() + '-' + Math.random().toString(36).slice(2);
                window.__api68Pending = window.__api68Pending || {};
                window.__api68Pending[id] = { resolve, reject };
                window.webkit.messageHandlers.api68.postMessage({ id, url });
              });
            }
            return originalFetch(input, init);
          };
          window.__api68Resolve = (id, status, body, error) => {
            const p = window.__api68Pending && window.__api68Pending[id];
            if (!p) return;
            delete window.__api68Pending[id];
            if (error) { p.reject(new Error(error)); return; }
            p.resolve(new Response(body, { status, headers: { 'Content-Type': 'application/json; charset=utf-8' } }));
          };
        })();
        """
        content.addUserScript(WKUserScript(source: bridge, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        // Read-only diagnostic probe for the embedded betting page. It never clicks or submits.
        let betProbe = """
        (() => {
          try {
            if (window.top === window || !location.hostname || location.protocol !== 'https:') return;
            // Receive locally calculated candidates from the app page. This handshake is read-only;
            // it does not select numbers, fill stakes, or submit any betting order.
            window.addEventListener('message', ev => {
              try {
                const d = ev.data;
                if (d && d.type === 'AU10_COORD_ACTION') {
                  if (ev.source !== window.parent) return;
                  const coords = d.coords || {};
                  const nums = Array.isArray(d.nums) ? d.nums.map(Number) : [];
                  if (nums.length !== 6 || new Set(nums).size !== 6 || nums.some(n => !Number.isInteger(n) || n < 1 || n > 10) || !Array.isArray(coords.numbers)) throw new Error('候选号必须是1-10内不重复的6个号码');
                  const wait = ms => new Promise(resolve => setTimeout(resolve,ms));
                  const clickAt = (x,y,label) => {
                    x=Number(x); y=Number(y);
                    if (!Number.isFinite(x)||!Number.isFinite(y)||x<0||y<0||x>=innerWidth||y>=innerHeight) throw new Error(label+'坐标超出当前网页可视区域；已停止，未继续点击');
                    const el=document.elementFromPoint(x,y);
                    if (!el || !el.getClientRects().length) throw new Error(label+'坐标未命中可见网页元素；已停止');
                    el.click(); return el;
                  };
                  const report = msg => { try { window.webkit.messageHandlers.betProbe.postMessage({host:location.hostname,title:document.title||'',url:location.origin+location.pathname,controls:[],coordResult:msg,issue:String(d.issue||'')}); } catch(_) {} };
                  (async()=>{
                    let completed=0;
                    try {
                      for (const n of nums) { const point=coords.numbers[n-1]; if (!Array.isArray(point)||point.length<2) throw new Error('号码'+n+'没有配置坐标'); clickAt(point[0],point[1],'号码'+n); completed++; await wait(180); }
                      const amountPoint=coords.amount;
                      const inputEl=clickAt(amountPoint?.[0],amountPoint?.[1],'金额输入框');
                      if (!['INPUT','TEXTAREA'].includes(inputEl.tagName) || inputEl.disabled || inputEl.readOnly) throw new Error('金额坐标没有命中可编辑的金额输入框');
                      inputEl.focus();
                      const value=String(d.amount||'10');
                      const proto=Object.getPrototypeOf(inputEl);
                      const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
                      if(setter) setter.call(inputEl,value); else inputEl.value=value;
                      inputEl.dispatchEvent(new Event('input',{bubbles:true})); inputEl.dispatchEvent(new Event('change',{bubbles:true}));
                      await wait(250);
                      if (String(inputEl.value)!==value) throw new Error('金额输入后校验不一致；已停止，未点击下一步');
                      clickAt(coords.immediate?.[0],coords.immediate?.[1],'立即投注/下一步');
                      report('已完成坐标点击尝试：号码点击'+completed+'/6，金额字段校验为'+value+'；已尝试打开下一步页面。请核对实际页面；最终确认投注未点击。');
                    } catch(err) { report('坐标操作中止（已完成号码点击'+completed+'/6）：'+String(err&&err.message||err)); }
                  })();
                  return;
                }
                if (!d || d.type !== 'AU10_BET_CANDIDATES' || !Array.isArray(d.nums) || d.nums.length !== 6) return;
                window.__au10Candidates = {
                  issue: String(d.issue || '').slice(0,40),
                  nums: d.nums.map(n => String(n).slice(0,2))
                };
                try { window.parent.postMessage({type:'AU10_BET_CANDIDATES_ACK', issue:window.__au10Candidates.issue, nums:window.__au10Candidates.nums}, '*'); } catch (_) {}
                window.webkit.messageHandlers.betProbe.postMessage({
                  host: location.hostname, title: document.title || '',
                  url: location.origin + location.pathname, candidates: window.__au10Candidates,
                  controls: []
                });
              } catch (_) {}
            });
            const report = () => {
              const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
              const labelOf = el => {
                const labels = el.labels ? Array.from(el.labels).map(x => x.innerText || x.textContent || '').join(' ') : '';
                const tag = (el.tagName || '').toLowerCase();
                const typ = (el.type || '').toLowerCase();
                // Never inspect or report typed values from text/password/email inputs.
                const safeText = (tag === 'input' || tag === 'textarea')
                  ? (['button','submit','reset','radio','checkbox'].includes(typ) ? (el.getAttribute('aria-label') || el.getAttribute('name') || '') : '')
                  : (el.innerText || el.textContent || '');
                return String(labels + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.placeholder || '') + ' ' + safeText).replace(/\\s+/g,' ').trim().slice(0,100);
              };
              const controls = Array.from(document.querySelectorAll('button,input,select,textarea,[role="button"],[role="radio"],[role="checkbox"],a,[onclick],label,li,span,div'))
                .filter(el => visible(el) && (
                  ['BUTTON','INPUT','SELECT','TEXTAREA','A','LABEL','LI'].includes(el.tagName) ||
                  el.hasAttribute('onclick') || el.hasAttribute('role') ||
                  /champion|冠军|投注|金额|立即|确认|submit|bet|number|option|select|radio|checkbox/i.test(String(el.className || '')+' '+labelOf(el))
                )).slice(0,220).map(el => {
                  const rect = el.getBoundingClientRect();
                  const typ = (el.type || '').slice(0,30);
                  return {
                    tag: el.tagName.toLowerCase(), type: typ,
                    text: labelOf(el), role: el.getAttribute('role') || '',
                    name: (el.getAttribute('name') || '').slice(0,80),
                    id: (el.id || '').slice(0,80),
                    cls: (typeof el.className === 'string' ? el.className : '').slice(0,100),
                    parentText: String((el.parentElement && (el.parentElement.innerText || el.parentElement.textContent)) || '').replace(/\\s+/g,' ').trim().slice(0,140),
                    grandparentText: String((el.parentElement && el.parentElement.parentElement && (el.parentElement.parentElement.innerText || el.parentElement.parentElement.textContent)) || '').replace(/\\s+/g,' ').trim().slice(0,180),
                    disabled: !!el.disabled,
                    checked: !!el.checked,
                    x: Math.round(rect.x), y: Math.round(rect.y),
                    w: Math.round(rect.width), h: Math.round(rect.height)
                  };
                });
              window.webkit.messageHandlers.betProbe.postMessage({
                host: location.hostname, title: document.title || '',
                url: location.origin + location.pathname, controls
              });
            };
            // Respond to the app's explicit read-only probe button, including after initial page load.
            window.addEventListener('message', ev => {
              try {
                if (ev.data && ev.data.type === 'AU10_BET_PROBE_REQUEST' && ev.data.readOnly === true) report();
              } catch (_) {}
            });
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', report, {once:true});
            else report();
            new MutationObserver(() => { if (!window.__betProbeQueued) { window.__betProbeQueued = true; setTimeout(() => { window.__betProbeQueued = false; report(); }, 800); } }).observe(document.documentElement, {childList:true,subtree:true});
          } catch (_) {}
        })();
        """
        content.addUserScript(WKUserScript(source: betProbe, injectionTime: .atDocumentEnd, forMainFrameOnly: false))

        let config = WKWebViewConfiguration()
        config.userContentController = content
        let web = WKWebView(frame: .zero, configuration: config)
        web.translatesAutoresizingMaskIntoConstraints = false
        web.backgroundColor = controller.view.backgroundColor
        web.isOpaque = false
        controller.view.addSubview(web)
        NSLayoutConstraint.activate([
            web.leadingAnchor.constraint(equalTo: controller.view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: controller.view.trailingAnchor),
            web.topAnchor.constraint(equalTo: controller.view.topAnchor),
            web.bottomAnchor.constraint(equalTo: controller.view.bottomAnchor)
        ])
        self.webView = web

        // XcodeGen may package Web/index.html either in a Web folder or at the bundle root.
        let htmlURL = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web")
            ?? Bundle.main.url(forResource: "index", withExtension: "html")
        if let url = htmlURL {
            web.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        } else {
            let message = UILabel()
            message.text = "网页资源没有打进安装包。请重新构建 IPA。"
            message.textColor = .white
            message.textAlignment = .center
            message.numberOfLines = 0
            message.translatesAutoresizingMaskIntoConstraints = false
            controller.view.addSubview(message)
            NSLayoutConstraint.activate([
                message.leadingAnchor.constraint(equalTo: controller.view.leadingAnchor, constant: 24),
                message.trailingAnchor.constraint(equalTo: controller.view.trailingAnchor, constant: -24),
                message.centerYAnchor.constraint(equalTo: controller.view.centerYAnchor)
            ])
        }
        return true
    }

    // Keep the screen awake across every in-app page, including after returning from background.
    func applicationWillEnterForeground(_ application: UIApplication) {
        UIApplication.shared.isIdleTimerDisabled = true
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        UIApplication.shared.isIdleTimerDisabled = true
    }
}

extension AppDelegate: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "betProbe" {
            guard let body = message.body as? [String: Any],
                  let host = body["host"] as? String,
                  let title = body["title"] as? String,
                  let controls = body["controls"] as? [[String: Any]] else { return }
            var safe: [String: Any] = ["host": host, "title": title, "controls": controls]
            // Forward the coordinate-action outcome and issue to the app UI.
            // Without these fields the webpage reports a result, but the UI silently drops it.
            if let coordResult = body["coordResult"] as? String {
                safe["coordResult"] = String(coordResult.prefix(500))
                safe["issue"] = String((body["issue"] as? String ?? "").prefix(40))
            }
            if let candidate = body["candidates"] as? [String: Any],
               let nums = candidate["nums"] as? [String], nums.count == 6,
               nums.allSatisfy({ $0.count <= 2 && Int($0) != nil }) {
                safe["candidates"] = [
                    "issue": String((candidate["issue"] as? String ?? "").prefix(40)),
                    "nums": nums
                ]
            }
            guard JSONSerialization.isValidJSONObject(safe),
                  let data = try? JSONSerialization.data(withJSONObject: safe),
                  let json = String(data: data, encoding: .utf8) else { return }
            DispatchQueue.main.async { [weak self] in
                self?.webView?.evaluateJavaScript("window.postMessage({type:'AU10_BET_PROBE', data:\(json)}, '*');")
            }
            return
        }
        guard message.name == "api68",
              let body = message.body as? [String: Any],
              let id = body["id"] as? String,
              let rawURL = body["url"] as? String,
              let url = URL(string: rawURL),
              url.host == "api.api68.com",
              url.scheme == "https" else { return }

        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue("application/json, */*", forHTTPHeaderField: "Accept")
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            let status = (response as? HTTPURLResponse)?.statusCode ?? 502
            let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
            let errorText = error?.localizedDescription ?? ""
            DispatchQueue.main.async {
                guard let webView = self?.webView else { return }
                let bodyJSON = try? JSONSerialization.data(withJSONObject: [
                    "id": id, "status": status, "body": text, "error": errorText.isEmpty ? NSNull() : errorText as Any
                ])
                guard let bodyJSON, let argument = String(data: bodyJSON, encoding: .utf8) else { return }
                webView.evaluateJavaScript("""
                  (() => {
                    const x = \(argument);
                    window.__api68Resolve(x.id, x.status, x.body, x.error || null);
                  })();
                """)
            }
        }.resume()
    }
}
