import { getStore } from "@netlify/blobs";

const API_URL =
  "https://api.api68.com/pks/getLotteryPksInfo.do?lotCode=10012";

const HISTORY_URL =
  "https://api.api68.com/pks/getPksHistoryList.do?lotCode=10012&date=";

const STORE_NAME = "au10-real-history";
const STORE_KEY = "records";

function extractRecords(json) {
  // Walk the whole response tree: API68 has used different names for history arrays.
  const queue = [json];
  const seen = new Set();

  while (queue.length) {
    const candidate = queue.shift();
    if (!candidate || typeof candidate !== "object" || seen.has(candidate)) continue;
    seen.add(candidate);

    if (Array.isArray(candidate)) {
      const objects = candidate.filter((item) => item && typeof item === "object" && !Array.isArray(item));
      if (objects.length) return objects;
      continue;
    }

    const hasIssue = [
      "issue", "issueNo", "expect", "period", "drawIssue", "preDrawIssue",
      "lotteryNo", "drawNo", "term", "preDrawIssueNo"
    ].some((key) => candidate[key] != null);
    const hasNumbers = [
      "preDrawCode", "openCode", "drawCode", "number", "numbers", "lotteryCode",
      "firstNum"
    ].some((key) => candidate[key] != null);
    if (hasIssue && hasNumbers) return [candidate];

    for (const value of Object.values(candidate)) {
      if (value && typeof value === "object") queue.push(value);
    }
  }

  return [];
}

function summarizeShape(value, depth = 0) {
  if (Array.isArray(value)) {
    return { type: "array", length: value.length, firstItemKeys: value[0] && typeof value[0] === "object" ? Object.keys(value[0]).slice(0, 30) : [] };
  }
  if (!value || typeof value !== "object") return { type: typeof value };
  const summary = { type: "object", keys: Object.keys(value).slice(0, 40) };
  if (depth < 2) {
    for (const key of ["data", "result", "list", "records", "rows", "info", "current", "lottery"]) {
      if (value[key] && typeof value[key] === "object") {
        summary[key] = summarizeShape(value[key], depth + 1);
      }
    }
  }
  return summary;
}

function normalizeRecord(item) {
  const issue =
    item?.issue ??
    item?.issueNo ??
    item?.expect ??
    item?.period ??
    item?.drawIssue ??
    item?.preDrawIssue ??
    item?.lotteryNo ??
    item?.drawNo ??
    item?.term;

  const time =
    item?.time ??
    item?.openTime ??
    item?.drawTime ??
    item?.openTimeStr ??
    item?.preDrawTime ??
    item?.lotteryTime ??
    "";

  const rawNumbers =
    item?.preDrawCode ??
    item?.openCode ??
    item?.drawCode ??
    item?.number ??
    item?.numbers ??
    item?.lotteryCode ??
    "";

  const numbers = Array.isArray(rawNumbers)
    ? rawNumbers.map(String)
    : String(rawNumbers).split(/[,\s]+/).filter(Boolean);

  const champion =
    item?.champion ??
    item?.first ??
    item?.firstNum ??
    numbers[0];

  if (issue == null || champion == null) return null;

  return {
    issue: String(issue),
    time: String(time),
    champion: String(champion).padStart(2, "0"),
    numbers,
  };
}

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: { accept: "application/json" },
    signal: AbortSignal.timeout(12000),
  });

  if (!response.ok) {
    throw new Error(`开奖接口 HTTP ${response.status}`);
  }

  return response.json();
}

export default async function handler() {
  const store = getStore({ name: STORE_NAME, consistency: "strong" });
  const oldRecords = (await store.get(STORE_KEY, { type: "json" })) || [];

  const diagnostics = {
    oldRecordCount: Array.isArray(oldRecords) ? oldRecords.length : 0,
    latestHttpOk: false,
    latestCandidateCount: 0,
    latestNormalizedCount: 0,
    historyDatesTried: 0,
    historyCandidateCount: 0,
    historyNormalizedCount: 0,
    historyErrors: [],
    historyResponseShapes: [],
    latestResponseShape: null,
  };

  try {
    const latestJson = await fetchJson(API_URL);
    diagnostics.latestHttpOk = true;
    diagnostics.latestResponseShape = summarizeShape(latestJson);
    const latestCandidates = extractRecords(latestJson);
    diagnostics.latestCandidateCount = latestCandidates.length;
    const normalizedLatest = latestCandidates.map(normalizeRecord).filter(Boolean);
    diagnostics.latestNormalizedCount = normalizedLatest.length;
    const latest = normalizedLatest[0];

    if (!latest) {
      console.error("最新开奖数据解析诊断:", JSON.stringify(diagnostics));
      throw new Error("无法识别最新开奖数据格式；诊断信息已记录");
    }

    const merged = new Map();

    for (const record of oldRecords) {
      if (record?.issue) merged.set(String(record.issue), record);
    }

    merged.set(latest.issue, latest);

    const now = new Date();
    const dates = new Set();

    for (const record of [...merged.values()]) {
      if (record.time) {
        const date = record.time.slice(0, 10).replaceAll("-", "");
        if (/^\d{8}$/.test(date)) dates.add(date);
      }
    }

    // Re-scan the most recent seven calendar days on every scheduled run.
    // This repairs missing cloud history even when older stored records have no time field.
    for (let offset = 0; offset < 7; offset++) {
      const day = new Date(Date.UTC(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        now.getUTCDate() - offset
      ));
      dates.add(
        day.getUTCFullYear() +
        String(day.getUTCMonth() + 1).padStart(2, "0") +
        String(day.getUTCDate()).padStart(2, "0")
      );
    }

    diagnostics.historyDatesTried = dates.size;
    for (const date of dates) {
      try {
        // API68 history endpoint expects YYYY-MM-DD, matching the browser app.
        const apiDate = date.length === 8
          ? `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}`
          : date;
        const historyJson = await fetchJson(
          HISTORY_URL + encodeURIComponent(apiDate)
        );

        if (diagnostics.historyResponseShapes.length < 3) {
          diagnostics.historyResponseShapes.push({ date: apiDate, shape: summarizeShape(historyJson) });
        }
        const historyCandidates = extractRecords(historyJson);
        diagnostics.historyCandidateCount += historyCandidates.length;
        const history = historyCandidates.map(normalizeRecord).filter(Boolean);
        diagnostics.historyNormalizedCount += history.length;

        for (const record of history) {
          if (!merged.has(record.issue)) {
            merged.set(record.issue, record);
          }
        }
      } catch (error) {
        diagnostics.historyErrors.push({ date, error: error.message });
        console.error(`历史补录失败 ${date}:`, error.message);
      }
    }

    const records = [...merged.values()]
      .sort((a, b) => a.issue.localeCompare(b.issue, "en", {
        numeric: true,
      }))
      .slice(-500);

    await store.set(STORE_KEY, JSON.stringify(records), {
      metadata: {
        updatedAt: new Date().toISOString(),
        latestIssue: latest.issue,
        count: records.length,
      },
    });

    // Log only counts/field names, never full draw payloads or credentials.
    const savedAfterWrite = await store.get(STORE_KEY, { type: "json" });
    diagnostics.savedCountAfterWrite = Array.isArray(savedAfterWrite) ? savedAfterWrite.length : 0;
    diagnostics.latestIssueSaved = Array.isArray(savedAfterWrite)
      ? savedAfterWrite.some((record) => String(record?.issue) === String(latest.issue))
      : false;
    console.log("开奖更新成功诊断:", JSON.stringify({
      ...diagnostics,
      latestIssue: latest.issue,
      finalCount: records.length,
    }));

    return Response.json({
      ok: true,
      latestIssue: latest.issue,
      count: records.length,
      updatedAt: new Date().toISOString(),
      diagnostics,
    });
  } catch (error) {
    console.error("开奖更新失败:", error);

    return Response.json(
      {
        ok: false,
        error: error.message,
        retainedRecords: Array.isArray(oldRecords) ? oldRecords.length : 0,
        diagnostics,
      },
      { status: 500 }
    );
  }
}

export const config = {
  schedule: "*/5 * * * *",
};