import { getStore } from "@netlify/blobs";

const STORE_NAME = "au10-real-history";
const STORE_KEY = "records";
const PREDICTION_STORE_NAME = "au10-prediction-history";
const PREDICTION_STORE_KEY = "predictions";

function predictAt(records) {
  if (!Array.isArray(records) || records.length < 15) return null;
  const a = records;
  const N = a.length;
  const current = Number(a[N - 1].champion);
  const hist = Array.from({ length: 10 }, () => ({ count: 0, weight: 0 }));
  const trend = Array(10).fill(0);

  for (let i = 1; i <= N - 2; i++) {
    if (Number(a[i].champion) !== current) continue;
    const d = ((Number(a[i + 1].champion) - Number(a[i].champion)) % 10 + 10) % 10;
    const w = 1 + (i / (N - 1)) * 0.6;
    hist[d].count++;
    hist[d].weight += w;
  }

  const start = Math.max(1, N - 20);
  for (let k = start; k <= N - 2; k++) {
    const d = ((Number(a[k + 1].champion) - Number(a[k].champion)) % 10 + 10) % 10;
    trend[d]++;
  }

  const ranks = hist.map((h, d) => ({
    d,
    count: h.count,
    trend: trend[d],
    score: h.weight + trend[d] * 1.5,
  })).sort((x, y) => y.score - x.score || y.count - x.count || x.d - y.d);

  const nums = [];
  const seen = new Set();
  for (const rank of ranks) {
    const n = ((current - 1 + rank.d) % 10) + 1;
    if (!seen.has(n)) {
      nums.push(n);
      seen.add(n);
    }
    if (nums.length === 6) break;
  }
  if (nums.length !== 6) return null;
  return nums;
}

function normalizeRecords(input) {
  if (!Array.isArray(input)) return [];
  const map = new Map();
  for (const item of input) {
    const issue = String(item?.issue ?? "").trim();
    const champion = Number(item?.champion ?? item?.numbers?.[0]);
    if (!issue || !Number.isInteger(champion) || champion < 1 || champion > 10) continue;
    map.set(issue, {
      issue,
      time: String(item?.time ?? ""),
      champion,
      numbers: Array.isArray(item?.numbers) ? item.numbers : [],
    });
  }
  return [...map.values()].sort((a, b) => a.issue.localeCompare(b.issue, "en", { numeric: true }));
}

export default async function handler() {
  try {
    const store = getStore({ name: STORE_NAME, consistency: "strong" });
    const saved = await store.get(STORE_KEY, { type: "json" });
    const records = normalizeRecords(saved).slice(-288);
    if (records.length < 15) {
      return Response.json({
        ok: false,
        error: "有效历史记录不足15期，暂不能生成六个候选号。",
        recordCount: records.length,
        candidates: [],
        readOnly: true,
        bettingEnabled: false,
      }, { status: 200, headers: { "Cache-Control": "no-store" } });
    }

    const latest = records[records.length - 1];
    const candidates = predictAt(records);

    // Persist one prediction snapshot per source issue, then resolve it when a later draw exists.
    const predictionStore = getStore({ name: PREDICTION_STORE_NAME, consistency: "strong" });
    const storedPredictions = await predictionStore.get(PREDICTION_STORE_KEY, { type: "json" });
    const predictionMap = new Map();
    for (const item of Array.isArray(storedPredictions) ? storedPredictions : []) {
      if (item?.sourceIssue && Array.isArray(item.candidates)) {
        predictionMap.set(String(item.sourceIssue), item);
      }
    }

    for (const prediction of predictionMap.values()) {
      if (prediction.result) continue;
      const nextRecord = records.find((record) =>
        record.issue.localeCompare(String(prediction.sourceIssue), "en", { numeric: true }) > 0
      );
      if (nextRecord) {
        prediction.targetIssue = nextRecord.issue;
        prediction.actualChampion = nextRecord.champion;
        prediction.result = prediction.candidates.includes(nextRecord.champion) ? "命中" : "未命中";
        prediction.resolvedAt = new Date().toISOString();
      }
    }

    if (!predictionMap.has(latest.issue)) {
      predictionMap.set(latest.issue, {
        sourceIssue: latest.issue,
        sourceTime: latest.time,
        sourceChampion: latest.champion,
        candidates,
        targetIssue: null,
        actualChampion: null,
        result: "待开奖",
        createdAt: new Date().toISOString(),
      });
    }

    const predictionHistory = [...predictionMap.values()]
      .sort((a, b) => a.sourceIssue.localeCompare(b.sourceIssue, "en", { numeric: true }))
      .slice(-288);
    await predictionStore.set(PREDICTION_STORE_KEY, JSON.stringify(predictionHistory), {
      metadata: { updatedAt: new Date().toISOString(), count: predictionHistory.length, latestSourceIssue: latest.issue },
    });
    const resolvedPredictions = predictionHistory.filter(item => item.result === "命中" || item.result === "未命中");
    const hitHistory = [];
    const start = Math.max(14, records.length - 21);
    for (let i = start; i < records.length - 1; i++) {
      const prediction = predictAt(records.slice(0, i + 1));
      if (!prediction || prediction.length !== 6) continue;
      const actualChampion = records[i + 1].champion;
      hitHistory.push({
        issue: records[i + 1].issue,
        actualChampion,
        candidates: prediction,
        result: prediction.includes(actualChampion) ? "命中" : "未命中",
      });
    }

    return Response.json({
      ok: true,
      readOnly: true,
      bettingEnabled: false,
      algorithm: "same-champion weighted tail-difference plus recent trend; mirrored from dashboard predictAt",
      recordCount: records.length,
      latestIssue: latest.issue,
      latestTime: latest.time,
      latestChampion: latest.champion,
      candidates,
      candidateCount: candidates.length,
      predictionHistory,
      predictionStats: {
        resolved: resolvedPredictions.length,
        hits: resolvedPredictions.filter(item => item.result === "命中").length,
        misses: resolvedPredictions.filter(item => item.result === "未命中").length,
        pending: predictionHistory.filter(item => item.result === "待开奖").length,
      },
      backtest: {
        hits: hitHistory.filter(x => x.result === "命中").length,
        total: hitHistory.length,
        records: hitHistory.slice(-20).reverse(),
      },
      updatedAt: new Date().toISOString(),
    }, { status: 200, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("候选号只读接口失败:", error);
    return Response.json({
      ok: false,
      error: error.message,
      candidates: [],
      readOnly: true,
      bettingEnabled: false,
    }, { status: 500, headers: { "Cache-Control": "no-store" } });
  }
}
