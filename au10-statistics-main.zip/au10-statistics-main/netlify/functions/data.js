import { getStore } from "@netlify/blobs";

export default async () => {
  try {
    // Must match the store used by netlify/functions/update.js.
    const store = getStore({ name: "au10-real-history", consistency: "strong" });
    const saved = await store.get("records", { type: "json" });
    const count = Array.isArray(saved) ? saved.length : 0;
    console.log("云端数据接口诊断:", JSON.stringify({
      storeName: "au10-real-history",
      storeKey: "records",
      context: process.env.CONTEXT || null,
      deployId: process.env.DEPLOY_ID || null,
      savedType: Array.isArray(saved) ? "array" : typeof saved,
      savedCount: count
    }));

    return new Response(JSON.stringify({
      ok: true,
      count,
      records: Array.isArray(saved) ? saved : []
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({
      ok: false,
      error: error.message,
      records: []
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store"
      }
    });
  }
};